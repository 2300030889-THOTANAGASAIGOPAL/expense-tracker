// src/services/expenseService.js
import API from "./api";

export const addExpense = (userId, expense) =>
  API.post(`/expenses/${userId}`, expense);

export const getExpensesByUser = (userId) =>
  API.get(`/expenses/user/${userId}`);
