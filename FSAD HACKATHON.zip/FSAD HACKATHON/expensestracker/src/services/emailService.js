// src/services/emailService.js
import API from "./api";

export const sendResetEmail = (email) =>
  API.post("/auth/forgot-password", email, {
    headers: { "Content-Type": "text/plain" },
  });
