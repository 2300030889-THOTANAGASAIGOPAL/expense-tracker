import axios from "axios";

export const downloadPDF = (userId) => {
  axios
    .get(`http://localhost:8080/api/expenses/pdf/${userId}`, {
      responseType: "blob", // This will ensure the response is a blob (binary data)
    })
    .then((response) => {
      // Create a link element to trigger the download
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "expenses_report.pdf"); // Set the download file name
      document.body.appendChild(link);
      link.click(); // Programmatically click the link to start the download
      document.body.removeChild(link); // Clean up
    })
    .catch((error) => {
      console.error("Error downloading PDF:", error);
      alert("Error downloading the report");
    });
};
