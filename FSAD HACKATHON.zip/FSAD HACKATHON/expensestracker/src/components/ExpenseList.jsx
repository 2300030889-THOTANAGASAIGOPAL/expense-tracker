import React from 'react';
import './ExpenseList.css';

function ExpenseList({ expenses }) {
  return (
    <div className="expense-list">
      <h2>Expense History</h2>
      {expenses.length === 0 ? (
        <p>No expenses added yet.</p>
      ) : (
        <ul>
          {expenses.map((item) => (
            <li key={item.id}>
              <span>{item.title}</span>
              <span>₹{item.amount}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default ExpenseList;
