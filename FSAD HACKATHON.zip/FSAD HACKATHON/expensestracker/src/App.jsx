import React, { useState } from 'react';
import ExpenseForm from './components/ExpenseForm';
import ExpenseList from './components/ExpenseList';
import './App.css';

function App() {
  const [expenses, setExpenses] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState('');
  const [currentView, setCurrentView] = useState('login');

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  // CAPTCHA
  const generateCaptcha = () => {
    const a = Math.floor(Math.random() * 10);
    const b = Math.floor(Math.random() * 10);
    return { question: `${a} + ${b}`, answer: a + b };
  };

  const [captcha, setCaptcha] = useState(generateCaptcha());
  const [captchaInput, setCaptchaInput] = useState('');
  const [captchaError, setCaptchaError] = useState('');

  const resetCaptcha = () => {
    setCaptcha(generateCaptcha());
    setCaptchaInput('');
    setCaptchaError('');
  };

  const checkCaptcha = () => {
    return parseInt(captchaInput) === captcha.answer;
  };

  const handleLogin = () => {
    if (!username || !password) {
      alert('Please enter valid credentials!');
      return;
    }
    if (!checkCaptcha()) {
      setCaptchaError('Captcha is incorrect');
      return;
    }
    setUser(username);
    setIsLoggedIn(true);
    setCurrentView('expenses');
    resetCaptcha();
  };

  const handleSignUp = () => {
    if (!username || !password) {
      alert('Please fill in all fields!');
      return;
    }
    if (!checkCaptcha()) {
      setCaptchaError('Captcha is incorrect');
      return;
    }
    setUser(username);
    setIsLoggedIn(true);
    setCurrentView('expenses');
    resetCaptcha();
  };

  const handleResetPassword = () => {
    if (username) {
      alert(`Password reset link sent to ${username}`);
      setCurrentView('login');
    } else {
      alert('Please enter your username!');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUser('');
    setExpenses([]);
    setCurrentView('login');
  };

  const addExpenseHandler = (expense) => {
    setExpenses((prev) => [expense, ...prev]);
  };

  return (
    <div className="app-container">
      {/* Login */}
      {currentView === 'login' && (
        <div className="auth-container">
          <h2>Welcome to Expense Tracker</h2>
          <h3>one Solution for all your needs</h3>
          
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="input-field"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input-field"
          />

          <div className="captcha">
            <label>{captcha.question} = ?</label>
            <input
              type="number"
              placeholder="Enter captcha"
              value={captchaInput}
              onChange={(e) => setCaptchaInput(e.target.value)}
              className="input-field"
            />
            {captchaError && <p className="error-message">{captchaError}</p>}
          </div>

          <button onClick={handleLogin} className="submit-button">Login</button>

          <p className="link-text">
            Don't have an account? <span className="link-button" onClick={() => { setCurrentView('signup'); resetCaptcha(); }}>Sign Up</span>
          </p>
          <p className="link-text">
            Forgot password? <span className="link-button" onClick={() => setCurrentView('forgotpassword')}>Reset Password</span>
          </p>
        </div>
      )}

      {/* Sign Up */}
      {currentView === 'signup' && (
        <div className="auth-container">
          <h2>Sign Up</h2>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="input-field"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input-field"
          />

          <div className="captcha">
            <label>{captcha.question} = ?</label>
            <input
              type="number"
              placeholder="Enter captcha"
              value={captchaInput}
              onChange={(e) => setCaptchaInput(e.target.value)}
              className="input-field"
            />
            {captchaError && <p className="error-message">{captchaError}</p>}
          </div>

          <button onClick={handleSignUp} className="submit-button">Sign Up</button>

          <p className="link-text">
            Already have an account? <span className="link-button" onClick={() => { setCurrentView('login'); resetCaptcha(); }}>Login</span>
          </p>
        </div>
      )}

      {/* Forgot Password */}
      {currentView === 'forgotpassword' && (
        <div className="auth-container">
          <h2>Forgot Password</h2>
          <input
            type="text"
            placeholder="Enter Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="input-field"
          />
          <button onClick={handleResetPassword} className="submit-button">Reset Password</button>
          <p className="link-text">
            Remembered? <span className="link-button" onClick={() => setCurrentView('login')}>Login</span>
          </p>
        </div>
      )}

      {/* Expense Tracker */}
      {isLoggedIn && currentView === 'expenses' && (
        <div className="dashboard">
          <header className="header">
            <h1>Welcome, {user} 👋</h1>
            <button onClick={handleLogout} className="logout-button">Logout</button>
          </header>
          <ExpenseForm onAddExpense={addExpenseHandler} />
          <ExpenseList expenses={expenses} />
        </div>
      )}
    </div>
  );
}

export default App;
