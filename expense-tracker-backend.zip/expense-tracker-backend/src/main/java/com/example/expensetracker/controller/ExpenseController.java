package com.example.expensetracker.controller;

import com.example.expensetracker.model.Expense;
import com.example.expensetracker.model.User;
import com.example.expensetracker.repository.ExpenseRepository;
import com.example.expensetracker.repository.UserRepository;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/expenses")
@CrossOrigin(origins = "http://localhost:5173")
public class ExpenseController {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/{userId}")
    public Expense createExpense(@PathVariable Long userId, @RequestBody Expense expense) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent()) {
            expense.setUser(userOpt.get());
            return expenseRepository.save(expense);
        } else {
            throw new RuntimeException("User not found with ID: " + userId);
        }
    }

 // inside ExpenseController.java

    @GetMapping("/export/{userId}")
    public void exportToPDF(@PathVariable Long userId, HttpServletResponse response) throws IOException {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=expenses.pdf");

        Optional<User> user = userRepository.findById(userId);
        if (user.isPresent()) {
            List<Expense> expenses = expenseRepository.findByUser(user.get());
            pdfExportService.exportToPdf(response, expenses);
        } else {
            throw new RuntimeException("User not found");
        }
    }
}
