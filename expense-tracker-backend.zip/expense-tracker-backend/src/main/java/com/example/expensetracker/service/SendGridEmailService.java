package com.example.expensetracker.service;

import com.sendgrid.*;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;

import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class SendGridEmailService {

    private static final String SENDGRID_API_KEY = "YOUR_SENDGRID_API_KEY";
    private static final String FROM_EMAIL = "your-verified-email@example.com";

    public void sendResetEmail(String toEmail, String resetLink) {
        Email from = new Email(FROM_EMAIL);
        String subject = "Password Reset Request";
        Email to = new Email(toEmail);
        Content content = new Content("text/plain", "Click the link to reset your password: " + resetLink);
        Mail mail = new Mail(from, subject, to, content);

        SendGrid sg = new SendGrid(SENDGRID_API_KEY);
        Request request = new Request();

        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());
            Response response = sg.api(request);
            System.out.println("Email sent. Status: " + response.getStatusCode());
        } catch (IOException ex) {
            System.err.println("Error sending email: " + ex.getMessage());
        }
    }
}