package com.example.expensetracker.controller;

import com.example.expensetracker.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ForgotPasswordController {

    @Autowired
    private EmailService emailService;

    // POST endpoint to handle the password reset request
    @PostMapping("/api/auth/forgot-password")
    public String forgotPassword(@RequestBody String email) {
        emailService.sendPasswordResetEmail(email);
        return "Password reset link sent to your email!";
    }
}
